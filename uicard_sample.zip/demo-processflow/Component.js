sap.ui.define(['sap/ui/core/UIComponent'],
	function(UIComponent) {
	"use strict";

	var Component = UIComponent.extend("demo.processflow.Component", {

		metadata : {
			manifest: "json"
		}
	});

	return Component;

});
